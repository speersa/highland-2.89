#ifndef G__STDLIB_H
#define G__STDLIB_H
#ifndef G__STDSTRUCT
#pragma setstdstruct
#endif
#define 	EXIT_FAILURE (1)
#define 	EXIT_SUCCESS (0)
#define 	MB_CUR_MAX (1)
#define 	MB_LEN_MAX (16)
#define 	RAND_MAX (2147483647)
typedef unsigned int wchar_t;
#pragma include_noerr <stdfunc.dll>
#endif
