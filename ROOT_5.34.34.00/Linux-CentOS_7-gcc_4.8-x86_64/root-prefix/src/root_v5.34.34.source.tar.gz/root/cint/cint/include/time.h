#ifndef G__TIME_H
#define G__TIME_H
typedef unsigned long clock_t;
typedef long time_t;
#ifndef G__STDSTRUCT
#pragma setstdstruct
#endif
#define 	CLK_TCK (100)
#endif
